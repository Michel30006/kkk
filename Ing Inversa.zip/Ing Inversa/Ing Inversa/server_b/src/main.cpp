#include <drogon/drogon.h>

#include <algorithm>
#include <atomic>
#include <cstdlib>
#include <thread>
#include <vector>

#include "api.hpp"
#include "todus_transport.hpp"
#include "tds/config.hpp"
#include "tds/log.hpp"
#include "tds/pinger.hpp"
#include "tds/storage.hpp"
#include "tds/util.hpp"
#include "worker.hpp"

int main() {
  using namespace tds;
  init_logging("server_b");

  Config config;
  try {
    config = load_config_from_env();
  } catch (const std::exception& e) {
    spdlog::error("configuración inválida: {}", e.what());
    return 1;
  }
  config.service_name = "server_b";
  std::string err;
  if (!validate_config(config, err)) {
    spdlog::error("configuración inválida: {}", err);
    return 1;
  }
  spdlog::info("arrancando: {}", describe_config(config));
  spdlog::info("transporte: {}", describe_transport(config));

  const char* migrations_env = std::getenv("MIGRATIONS_DIR");
  const std::string migrations_dir =
      migrations_env != nullptr ? migrations_env : "./database/migrations";
  auto store = make_store(config.database_url, migrations_dir, err);
  if (!store) {
    spdlog::error("base de datos no disponible: {}", err);
    return 1;
  }
  store->set_lease_seconds(config.job_lease_seconds);

  auto transport = make_transport(config, err);
  if (!transport) {
    spdlog::error("transporte no disponible: {}", err);
    return 1;
  }
  if (config.transport == "todus") {
    if (!transport->connect(err)) {
      // No es fatal: el worker reintenta en cada trabajo. Pero conviene que el
      // operador lo sepa de inmediato.
      spdlog::error("no se pudo conectar a ToDus al arrancar: {}", err);
    }
  } else if (!transport->connect(err)) {
    spdlog::error("no se pudo preparar el transporte mock: {}", err);
    return 1;
  }

  ServerBStats stats;
  stats.started_at = unix_now();
  DeliveryWorker worker(*store, config, *transport, stats);

  std::atomic<bool> stop{false};
  std::vector<std::thread> workers;
  const int worker_count = std::max(1, config.max_concurrent_jobs);
  for (int i = 0; i < worker_count; ++i)
    workers.emplace_back([&worker, &stop, i] { worker.run(stop, i); });

  register_server_b_routes(*store, config, stats, worker, *transport);

  auto pinger = start_health_pinger(stop, "server_a", config.server_a_url,
                                    config.ping_interval_seconds,
                                    config.http_timeout_seconds * 1000,
                                    config.internal_token);

  drogon::app()
      .addListener(config.listen_address, config.port)
      .setThreadNum(2)
      .setClientMaxBodySize(64 * 1024)
      .setLogLevel(trantor::Logger::kWarn);

  spdlog::info("Servidor B escuchando en {}:{}", config.listen_address,
               config.port);
  drogon::app().run();

  stop.store(true);
  worker.wake();
  for (auto& thread : workers) thread.join();
  if (pinger.joinable()) pinger.join();
  transport->close();
  spdlog::info("Servidor B detenido");
  return 0;
}
