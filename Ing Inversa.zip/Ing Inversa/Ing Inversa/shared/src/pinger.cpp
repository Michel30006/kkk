#include "tds/pinger.hpp"

#include <chrono>

#include "tds/http.hpp"
#include "tds/log.hpp"

namespace tds {

std::thread start_health_pinger(const std::atomic<bool>& stop,
                                std::string peer_name, std::string peer_base_url,
                                int interval_seconds, int timeout_ms,
                                std::string internal_token) {
  return std::thread([&stop, peer_name = std::move(peer_name),
                      peer_base_url = std::move(peer_base_url), interval_seconds,
                      timeout_ms, token = std::move(internal_token)] {
    if (peer_base_url.empty()) return;
    spdlog::info("ping mutuo hacia {} cada {} s", peer_name, interval_seconds);
    while (!stop.load()) {
      HttpOptions options;
      options.timeout_ms = timeout_ms;
      if (!token.empty()) options.headers.push_back("X-Internal-Token: " + token);
      const auto started = std::chrono::steady_clock::now();
      const auto response = http_get(peer_base_url + "/health", options);
      const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                               std::chrono::steady_clock::now() - started)
                               .count();
      if (response.ok()) {
        spdlog::info("ping {} OK HTTP {} en {} ms", peer_name, response.status, elapsed);
      } else {
        spdlog::warn("ping {} falló: {} ({} ms)", peer_name,
                     response.error.empty() ? std::to_string(response.status)
                                            : response.error,
                     elapsed);
      }
      // Espera por tramos para atender la parada con rapidez.
      for (int waited = 0; waited < interval_seconds * 10 && !stop.load(); ++waited)
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
  });
}

}  // namespace tds
